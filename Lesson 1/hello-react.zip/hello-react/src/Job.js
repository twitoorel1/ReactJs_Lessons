import React from "react";

function Job({ job }) {
  return <div>My job is {job}</div>;
}

export default Job;
