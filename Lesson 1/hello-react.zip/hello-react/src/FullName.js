import React from "react";

function FullName({ firstName, lastName }) {
  return (
    <div>
      My full name is - {firstName} {lastName}
    </div>
  );
}

export default FullName;
