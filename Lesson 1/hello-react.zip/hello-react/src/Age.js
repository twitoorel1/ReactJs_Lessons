import React from "react";

function Age({ number }) {
  return <div>My age is {number}</div>;
}

export default Age;
